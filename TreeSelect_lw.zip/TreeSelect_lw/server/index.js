// Import modules
const express = require('express')

// Init express
const app = express()

// const routes = require('./routes/routes');

app.use(express.json())
app.use(express.urlencoded({ extended: false }))

// Link express to use main routes file

// PORT Setup:  Set server PORT as either one specified in config OR our default if not specified
// --> NOTE: listen() method takes a PORT and a "callback function" - where we pass back a console message
const PORT = process.env.PORT || 8080
app.listen(PORT, () => console.log(`Server is listening on port: ${PORT}`))
