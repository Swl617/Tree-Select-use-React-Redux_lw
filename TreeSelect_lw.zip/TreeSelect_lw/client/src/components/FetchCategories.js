import React, { Component, Fragment } from 'react'
// Antd
import 'antd/dist/antd.css'
import { TreeSelect, Card, Button, List } from 'antd'
// React Redux store
import store from '../store'
import { addItemAction, deleteItemAction } from '../store/actionCreators'
import { getClikListAction } from '../store/actionCreators.js'
// import categoryService from './server/categoryService'

const { TreeNode } = TreeSelect

// FetchCategories Component
class FetchCategories extends Component {
  constructor(props) {
    super(props)
    this.state = store.getState()
    this.onChange = this.onChange.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.deleteItem = this.deleteItem.bind(this)
    this.storeChange = this.storeChange.bind(this)
    store.subscribe(this.storeChange)
  }

  state = {
    value: '',
    list: {},
    data: {},
    err: '',
  }

  storeChange() {
    this.setState(store.getState())
  }

  componentDidMount() {
    // Load categories data result await through categories service get.
    const action = getClikListAction()
    store.dispatch(action)
  }
  // Select List Item function
  onChange = (value) => {
    const action = {
      type: 'selectItem',
      value: value,
    }
    store.dispatch(action)
  }
  // Delete List Item function
  deleteItem(index) {
    const action = deleteItemAction(index)
    store.dispatch(action)
  }
  // Add Selected item to the List Function
  doSubmit = (e) => {
    const action = addItemAction(e)
    store.dispatch(action)
  }
  // Fetch Categories data to the TreeSelect
  renderTreeNode = (categories) => {
    return categories.map((item) => {
      if (item.children && item.children.length > 0) {
        return (
          <TreeNode
            key={item.categoryId}
            title={item.name}
            value={item.categoryId}
          >
            {this.renderTreeNode(item.children)}
          </TreeNode>
        )
      }
      return (
        <TreeNode
          key={item.categoryId}
          title={item.name}
          value={item.categoryId}
        />
      )
    })
  }
  // TreeSelect componet OutPut Section
  render() {
    const { categories, value, list } = this.state
    return (
      <Fragment>
        <Card bordered={false}>
          <h1>Tree Select LW</h1>
          {/* OPEN REDUX SAGA AND ANT DESGIN SECTION*/}
          {/* This section for fetchcategories data store in the redux using Redux  Saga */}
          <h2>FetchCategories</h2>

          {/* Open TreeSelect section */}
          <TreeSelect
            dropdownClassName="categorytree "
            style={{ width: '100%' }}
            value={value}
            dropdownStyle={{
              maxHeight: 800,
              overflow: 'auto',
              marginRight: '20px',
            }}
            dropdownMatchSelectWidth
            placeholder="Please select"
            treeDefaultExpandAll
            onChange={this.onChange}
            // onClick={this.changeValue}
          >
            {this.renderTreeNode(categories)}
          </TreeSelect>

          <Button
            type="primary"
            style={{ width: '100%' }}
            onClick={this.doSubmit}
          >
            Add
          </Button>
          {/* Close TreeSelect section */}

          {/* Open List select item section */}
          <h2>List Select Item</h2>
          <List
            bordered
            value={value}
            dataSource={list}
            renderItem={(item) => (
              <List.Item
                onClick={(item, index) => {
                  this.deleteItem(item, index)
                }}
              >
                <h3>{item}</h3>
              </List.Item>
            )}
          ></List>
          {/* Close List select item section */}

          {/* CLOSE REDUX SAGA AND ANT DESGIN SELECTION */}
        </Card>
      </Fragment>
    )
  }
}
export default FetchCategories
