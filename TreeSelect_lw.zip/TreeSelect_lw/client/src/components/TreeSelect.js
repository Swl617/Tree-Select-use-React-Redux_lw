import React, { Component } from 'react'
// eslint-disable-next-line
import FetchCategories from './FetchCategories'

class TreeSelect extends Component {
  render() {
    return <FetchCategories />
  }
}
export default TreeSelect
