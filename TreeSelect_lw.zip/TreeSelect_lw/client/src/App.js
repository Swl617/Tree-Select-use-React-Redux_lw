import React, { Fragment } from 'react'
// import { BrowserRouter as Router, Route} from 'react-router-dom';

import TreeSelect from './components/TreeSelect'

//Import local component

function App() {
  return (
    <Fragment>
      <div className="App">
        <TreeSelect />
      </div>
    </Fragment>
  )
}

export default App
