import { takeEvery } from 'redux-saga/effects'
import { GET_ACTION_LIST } from './actionType'
// eslint-disable-next-line
function* Sagas() {
  yield takeEvery(GET_ACTION_LIST, getList)
}
// eslint-disable-next-line
function* getList() {
  console.log('value')
}

export default Sagas
