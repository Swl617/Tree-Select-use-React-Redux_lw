import { GET_ACTION_LIST, GET_LIST, ADD_ITEM, DELETE_ITEM } from './actionType'

export const addItemAction = () => ({
  type: ADD_ITEM,
})

export const getListAction = (data) => ({
  type: GET_LIST,
  data,
})

export const deleteItemAction = (index) => ({
  type: DELETE_ITEM,
  index,
})

export const getClikListAction = () => ({
  type: GET_ACTION_LIST,
})
