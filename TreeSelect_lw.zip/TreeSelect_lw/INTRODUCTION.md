Thank you for your reply to my email and coding test questions!

1. This test project I was using use `TreeSelect` component of `Ant Design` with [Create React App]. The programming language using`Javascript`.
2. The App in the terminal : in the server just use node ---- npm run dev----will run client locally (`localhost:3000`) and server(`localhost:8080`) both on time .
3. This Project the button fetch categories data through `redux saga`.
4. Through this code test, I just start using react with redux saga, the performance of the application components produced as me is not feel good and perfect. At present, it only realizes the basic options tree select function of the front-end and UI display. The server and backend have not yet been completed on time. The postman cannot be used for testing.The back-end end point and server settings will be setting as soon.
